# Enough
[![Hits](https://hits.sh/github.com/tingirifistik/Enough-Reborn.svg?label=views&color=007ec6)](https://hits.sh/github.com/tingirifistik/Enough-Reborn/)

<img src=https://github.com/tingirifistik/Enough-Reborn/assets/51286195/fc10a910-b4a4-4ff2-8058-62767b9af30f height="200px" width="400px"/>
<img src=https://user-images.githubusercontent.com/51286195/209442235-7069b8e7-b3f3-4b70-82cb-a86014836be0.png height="200px" width="400px"/>


<h2>Kurulum</h2>

```console
git clone https://MALATYA.OSURUK.G�C�...
cd MALATYAOSURU�U
pip3 install -r requirements.txt
python3 enough.py
```


<h2>Discord</h2>

Bot'un �al��abilmesi i�in 'Privileged Gateway Intents' se�eneklerinin hepsinin aktif olmas� gerekmektedir.

<h2>Discord Selfbot</h2>

**Token bulma:**

1- Taray�c�dan bot olarak kullanaca��n�z Discord hesab�na giriniz.<br>
2- Taray�c� konsolunu a��n�z.<br>
3- A� trafi�i izleme b�l�m�ne geliniz.<br>
4- Konsolu kapatmadan, Discord'da bu oturum boyunca t�klamad���n�z bir sohbete t�klay�n�z.<br>
5- Sonu *messages?limit=50* ile biten iste�e t�klay�n�z.<br>
6- �ste�in *Header* k�sm�ndaki *Authorization* de�eri sizin token'�n�zd�r.<br>
7- Bu token'� *discord-selfbot-enough.py*'de *token* k�sm�na yaz�n�z. (str olarak)<br>

**Chat Id Bulma:**

1- Bot hesab� ile mesajla�aca��n�z kendi orijinal hesab�n�zdan bot'a bir tane mesaj at�n�z.<br>
2- Taray�c�da Discord'u a��n ve bot hesab�na giri� yap�n�z, ard�ndan ger�ek hesab�n�z�n �zerine t�klay�n.<br>
3- Url'deki *@me*'den sonraki say� sizin sohbet id'nizdir.<br>
4- Bu id'yi *discord-selfbot-enough.py*'de *chat_id* k�sm�na yaz�n�z. (int olarak)<br><br>
**Not:** E�er bot'u Discord sunucusunda kullanacaksan�z, *channels*'dan sonra gelen, taksim ile ayr�lm�� iki say�dan ikincisi sohbet id'nizdir.
<br><br>
<a href="https://www.buymeacoffee.com/tingirifistik" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>